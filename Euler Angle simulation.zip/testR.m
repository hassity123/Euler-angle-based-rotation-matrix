close;
clear all;
clc;
t=0:0.01:1; % sampling rate
for i =1:length(t)
    phi(i)=pi/3*sin(2*pi*t(i)); % rotation angle for z
    th(i)=pi/4*sin(2*pi*t(i));  % rotation angle for x and y
    R(:,:,i)=Rot('z',phi(i))*Rot('y',th(i))*Rot('x',th(i));
    Test(:,:,i)=R(:,:,i)'*R(:,:,i)% Rotation matrix property test
    
    [gamma, beta,alpha]=dcm2angle(R,'ZYX'); % get euler angle from R
    
    roll(i)=gamma(i);    
    pitch(i)=beta(i);
    yaw(i)=alpha(i);
    % Take time derivative of Euler angles 
    rolld=diff(roll);    
    pitchd=diff(pitch)
    yawd=diff(yaw);
    % Angular velocity based on the ZYX order 
    T=[0 -sin(roll(i)) cos(pitch(i))*cos(roll(i)); 0 cos(roll(i)) cos(pitch(i))*sin(roll(i));1 0 -sin(pitch(i))];
    ed(:,i)=[yaw(i);roll(i);pitch(i)]; % Euler rate vector  
    w(:,i)=T*ed(:,i) % Angular velcity
    wx(i)=w(1,i);    % Angular velcity component x
    wy(i)=w(2,i);    % Angular velcity component y
    wz(i)=w(3,i);    % Angular velcity component z
    
    % Robotics tool box (peter corke) 
%     tranimate(R(:,:,i)) % Aniate to visualize from robotix toolbox 
end
% Euler angle derivation

 figure(1),plot(t,yaw), hold on 
 plot(t,roll), hold on
 plot(t,pitch)
 
 figure(2),plot(t(1:100),yawd), hold on 
 plot(t(1:100),rolld), hold on
 plot(t(1:100),pitchd)
 
 figure(3),plot(t,wx), hold on 
 plot(t,wy), hold on
 plot(t,wz)
 
 


    
